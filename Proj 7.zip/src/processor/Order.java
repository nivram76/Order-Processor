package processor;

import java.io.*;
import java.util.Scanner;
import java.util.TreeMap;

public class Order implements Runnable {

	private int id;
	private String baseFile;
	private TreeMap<String, Item> totals = new TreeMap<String, Item>();
	private TreeMap<String, Item> items = new TreeMap<String, Item>();

	public Order(String baseFile, int id, TreeMap<String, Item> totals) {
		this.baseFile = baseFile + ".txt";
		this.totals = totals;
		this.id = id;
	}

	public void run() {
		System.out.println("Reading order for client with id: " + id);

		File order = new File(baseFile);

		try {
			synchronized (totals) {
				Scanner sc = new Scanner(order);
				sc.nextLine();

				while (sc.hasNextLine()) {
					String item = sc.next();

					if (items.containsKey(item)) {
						items.get(item).increaseQuantity();
					} else {
						items.put(item, new Item(1, totals.get(item).getCost()));
					}

					totals.get(item).increaseQuantity();
					sc.nextLine();
				}
				
				sc.close();
			}

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
	}

	public TreeMap<String, Item> getItems() {
		return items;
	}
	
	public int getId() {
		return id;
	}
	
	public String getBaseFile() {
		return baseFile;
	}
}
