package processor;

import java.io.*;
import java.text.NumberFormat;
import java.util.*;

public class OrdersProcessor {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		String dataFile;
		System.out.print("Enter item's data file name:");
		dataFile = sc.nextLine();

		TreeMap<String, Item> totals = new TreeMap<String, Item>();
		File itemData = new File(dataFile);

		try {
			Scanner sc2 = new Scanner(itemData);

			while (sc2.hasNextLine()) {
				totals.put(sc2.next(), new Item(0, sc2.nextDouble()));
			}

			sc2.close();
		} catch (FileNotFoundException e1) {

			e1.printStackTrace();
		}

		System.out.print("Enter 'y' for multiple threads, any other character for otherwise:");
		boolean multiple;
		if (sc.nextLine().equals("y")) {
			multiple = true;
		} else {
			multiple = false;
		}

		int orderNum;
		System.out.print("Enter number of orders to process:");
		orderNum = sc.nextInt();
		sc.nextLine();

		String baseFile;
		System.out.print("Enter order's base filename:");
		baseFile = sc.nextLine();

		String resultsFile;
		System.out.print("Enter result's file name:");
		resultsFile = sc.nextLine();
		sc.close();

		ArrayList<Thread> threads = new ArrayList<Thread>();
		ArrayList<Order> orders = new ArrayList<Order>();

		for (int i = 1; i <= orderNum; i++) {
			orders.add(new Order(baseFile + i, 1000 + i, totals));
		}

		if (!multiple) { // single thread
			long startTime = System.currentTimeMillis();

			for (Order o : orders) {
				File order = new File(o.getBaseFile());

				Scanner sc1;
				try {
					sc1 = new Scanner(order);
					sc1.nextLine();

					while (sc1.hasNextLine()) {
						String item = sc1.next();

						if (o.getItems().containsKey(item)) {
							o.getItems().get(item).increaseQuantity();
						} else {
							o.getItems().put(item, new Item(1, totals.get(item).getCost()));
						}

						totals.get(item).increaseQuantity();
						sc1.nextLine();
					}

					sc1.close();
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				}
			}
			
			long endTime = System.currentTimeMillis();
			System.out.println("Processing time (msec): " + (endTime - startTime));

		} else { // multithread
			long startTime = System.currentTimeMillis();

			for (int i = 0; i < orderNum; i++) {
				threads.add(new Thread(orders.get(i)));
			}

			
			for (int i = 0; i < orderNum; i++) {
				threads.get(i).start();
			}
			
			for(Thread t: threads) {
				try {
					t.join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			long endTime = System.currentTimeMillis();
			System.out.println("Processing time (msec): " + (endTime - startTime));
		}

		writeSummaryToResults(resultsFile, orders, totals);
		System.out.println("Results can be found in the file: " + resultsFile);
	}

	private static void writeSummaryToResults(String resultsFile, ArrayList<Order> orders,
			TreeMap<String, Item> totals) {

		try {
			FileWriter writer = new FileWriter(resultsFile);
			double totalCost = 0;
			int quantity;
			double cost;

			// individual orders
			for (Order o : orders) {
				totalCost = 0;
				writer.write("----- Order details for client with Id: " + o.getId() + " ----- \n");
				for (String s : o.getItems().keySet()) {
					cost = o.getItems().get(s).getCost();
					quantity = o.getItems().get(s).getQuantity();

					writer.write("Item's name: " + s + ", Cost per item: "
							+ NumberFormat.getCurrencyInstance().format(cost) + ", Quantity: " + quantity + ", Cost: "
							+ NumberFormat.getCurrencyInstance().format(cost * quantity) + "\n");
					totalCost += cost * quantity;
				}
				writer.write("Order Total: " + NumberFormat.getCurrencyInstance().format(totalCost) + "\n");
			}

			totalCost = 0;
			// summary for total orders
			writer.write("***** Summary of all orders *****\n");
			for (String s : totals.keySet()) {
				cost = totals.get(s).getCost();
				quantity = totals.get(s).getQuantity();

				if (quantity != 0) {
					writer.write("Summary - Item's name: " + s + ", Cost per item: "
							+ NumberFormat.getCurrencyInstance().format(totals.get(s).getCost()) + ", Number sold: "
							+ quantity + ", Item's Total: " + NumberFormat.getCurrencyInstance().format(cost * quantity)
							+ "\n");
					totalCost += cost * quantity;
				}
			}
			writer.write("Summary Grand Total: " + NumberFormat.getCurrencyInstance().format(totalCost) + "\n");

			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
