package processor;
public class Item {

	private int quantity;
	private double cost;
	
	public Item(int quantity, double cost) {
		this.quantity=quantity;
		this.cost=cost;
	}
	
	public int getQuantity() {
		return quantity;
	}
	
	public double getCost() {
		return cost;
	}
	
	public void increaseQuantity() {
		quantity++;
	}
	
}
